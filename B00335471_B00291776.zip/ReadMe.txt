Good afternoon Mr. Affleck,

The folder should contain:
	- The project: Carpool folder
	- The database script: DatabaseScript.sql
	- The background and technical document: BackgroundAndTechnicalDocument.pdf
	- The design documentation: Design Documentation.pdf

This project was made on Visual Studio 2017. 

The database used was locally created on SQL Server 2017, you must to create one on your device. The database script is available, it creates the tables and inserts some values.
To connect the database with the visual studio project you must open the file called Web.config on the project, on line 71, you must add your connection string.

Don't hesitate to contact us if you have problems with the project.

Regards,
Nathana�l Omnes